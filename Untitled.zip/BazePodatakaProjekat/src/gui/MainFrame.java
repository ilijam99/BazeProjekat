package gui;

import java.awt.Dimension;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import main.AppCore;

public class MainFrame extends JFrame implements Subscriber {
	
	 private static MainFrame instance = null;
	 
	 private AppCore appCore;
	    private JPanel bottomStatus;
	    private JTable jTable;
	
	    private JScrollPane jsp;
	
	    
	    public MainFrame() {
	    	
	    }
	    
	    public static MainFrame getInstance(){
	        if (instance==null){
	            instance=new MainFrame();
	            instance.initialise();
	        }
	        return instance;
	    }
	    
	    private void initialise() {

	        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	        jTable = new JTable();
	        jTable.setPreferredScrollableViewportSize(new Dimension(500, 400));
	        jTable.setFillsViewportHeight(true);
	        this.add(new JScrollPane(jTable));


	        this.pack();
	        this.setLocationRelativeTo(null);
	        this.setVisible(true);


	    }
	    
	    public void setAppCore(AppCore appCore) {
	        this.appCore = appCore;
	        this.appCore.addSubscriber(this);
	        this.jTable.setModel(appCore.getTableModel());
	    }
	    
	@Override
	public void onSubscribe(Subscription subscription) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNext(Object item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(Throwable throwable) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onComplete() {
		// TODO Auto-generated method stub
		
	}

}
