package main;

public class AppCore {

}
