package database;

import java.util.List;

import resource.DBNode;
import resource.data.Row;

public class DatabaseImplementation implements Database{

	private Repository repository;

	@Override
	public DBNode loadResource() {
		
		return repository.getSchema();
		
	}

	@Override
	public List<Row> readDataFromTable(String tableName) {
	
		
	
		return repository.get(tableName);
	}

}
