package observer;

public interface Subscriber {
	void update(Notification notification);
}
