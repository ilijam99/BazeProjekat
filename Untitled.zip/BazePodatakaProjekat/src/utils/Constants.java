package utils;

public class Constants {

	public static final String MSSQL_IP = "147.91.175.155";
    public static final String MSSQL_DATABASE = "tim_38_bp2020";
    public static final String MSSQL_USERNAME = "tim_38_bp2020";
    public static final String MSSQL_PASSWORD = "s7ahReQb";
    
}
